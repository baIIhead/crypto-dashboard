import requests
import time
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
from matplotlib import style
import numpy as np

SYMBOL = "BTCUSDT"
INTERVAL = "1m"
LIMIT = 50
SMA_PERIOD = 20

style.use('ggplot')

def get_klines(symbol, interval, limit):
    url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}"
    response = requests.get(url)
    data = response.json()
    return data

def calculate_sma(prices, period):
    if len(prices) < period:
        return None
    return sum(prices[-period:]) / period

def plot_candles(data):
    # Prepare data for candlestick plotting
    dates = [datetime.fromtimestamp(k[0]/1000) for k in data]
    opens = np.array([float(k[1]) for k in data])
    highs = np.array([float(k[2]) for k in data])
    lows = np.array([float(k[3]) for k in data])
    closes = np.array([float(k[4]) for k in data])

    fig, ax = plt.subplots()
    ax.set_title(f'{SYMBOL} Last {LIMIT} Candles')
    ax.set_xlabel('Time')
    ax.set_ylabel('Price')
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    ax.grid(True)

    # Width of candlestick elements
    width = 0.0006
    width2 = 0.0001

    for i in range(len(dates)):
        color = 'green' if closes[i] >= opens[i] else 'red'
        ax.plot([dates[i], dates[i]], [lows[i], highs[i]], color=color)  # wick
        ax.bar(dates[i], closes[i]-opens[i], width, bottom=opens[i], color=color)  # body

    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def main():
    print("Starting trading bot with candlestick chart...")
    prev_signal = None
    while True:
        klines = get_klines(SYMBOL, INTERVAL, LIMIT)
        close_prices = [float(k[4]) for k in klines]
        sma = calculate_sma(close_prices, SMA_PERIOD)
        if sma is None:
            print("Not enough data for SMA calculation.")
            time.sleep(60)
            continue

        last_price = close_prices[-1]

        if last_price > sma and prev_signal != "BUY":
            print(f"BUY signal: Price {last_price} crossed above SMA {sma:.2f}")
            prev_signal = "BUY"
        elif last_price < sma and prev_signal != "SELL":
            print(f"SELL signal: Price {last_price} crossed below SMA {sma:.2f}")
            prev_signal = "SELL"
        else:
            print(f"HOLD: Price {last_price}, SMA {sma:.2f}")

        plot_candles(klines)
        time.sleep(60)

if __name__ == "__main__":
    main()
